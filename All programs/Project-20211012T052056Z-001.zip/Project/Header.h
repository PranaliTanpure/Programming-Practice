
// Header file inclusion
#include <stdio.h>

// Function prototype
int Addition(int , int);
